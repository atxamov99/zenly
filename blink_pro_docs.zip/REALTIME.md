# Real-time System
Using Firestore streams.
