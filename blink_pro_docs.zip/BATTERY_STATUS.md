# Battery Tracking
Send battery %.
