# Performance
Optimize streams.
