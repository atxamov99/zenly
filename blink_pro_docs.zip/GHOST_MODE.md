# Ghost Mode
Hide location logic.
