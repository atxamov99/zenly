# Architecture
Clean Architecture + MVVM.
