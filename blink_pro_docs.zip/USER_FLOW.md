# User Flow
Onboarding → Add friends → Live map.
