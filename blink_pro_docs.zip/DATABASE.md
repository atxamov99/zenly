# Firestore Schema
Users, locations, friendships.
