# Folder Structure
lib/, services/, models/.
